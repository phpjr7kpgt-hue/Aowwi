CLOUD IPA BUILD (no Mac needed locally)

This project includes a GitHub Actions workflow at .github/workflows/ios-ipa.yml.
GitHub runs the build on a hosted macOS machine.

You need an Apple Developer Program membership and an Apple Distribution certificate
(.p12) plus an App Store provisioning profile for bundle ID:
com.tshiki.CodeManager

Important: In the workflow, the provisioning profile's display name must be exactly:
Tshiki App Store Profile
If yours has a different name, change PROVISIONING_PROFILE_SPECIFIER and the matching
profile name in ExportOptions.plist in the workflow.

1. Create a private GitHub repository and upload the contents of this folder.
2. In GitHub: Settings > Secrets and variables > Actions > New repository secret,
   add these secrets:
   - BUILD_CERTIFICATE_BASE64: base64 text of your .p12 certificate
   - P12_PASSWORD: password used when exporting the .p12
   - PROVISIONING_PROFILE_BASE64: base64 text of the .mobileprovision file
   - KEYCHAIN_PASSWORD: any strong temporary password
   - APPLE_TEAM_ID: your Apple Developer Team ID
3. Open the repository's Actions tab, choose "Build signed IPA", then "Run workflow".
4. When it finishes, open the workflow run and download the artifact named
   TshikiCodeManager-IPA. It contains the .ipa file.

Do not share certificate files, passwords, or these secrets with anyone. The workflow
uses an App Store-signed IPA; installation/distribution is through Apple's supported
TestFlight/App Store process, not direct ad-hoc installation.
