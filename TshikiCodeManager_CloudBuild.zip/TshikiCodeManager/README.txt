Tshiki Code Manager — iOS SwiftUI starter project

Features:
- Generate random codes with the Tshiki- prefix
- Choose 1, 7, 30, 90, or 365 day validity
- Stop/reactivate a code
- Reset a code's expiry from today using the selected duration
- Display remaining days and expiry date
- Save data locally on the device

Build:
1. Open TshikiCodeManager.xcodeproj in Xcode on a Mac.
2. Select an iPhone or iPad simulator/device.
3. Set your Apple Developer Team under Signing & Capabilities.
4. Build or Archive to create a signed IPA.

This starter is local-only. For real customer licenses, use a secure server/database
and server-side validation; local storage can be edited and is not secure licensing.
