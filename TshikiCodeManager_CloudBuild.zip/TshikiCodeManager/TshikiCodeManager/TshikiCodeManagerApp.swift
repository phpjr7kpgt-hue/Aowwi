import SwiftUI

struct LicenseCode: Identifiable, Codable {
    var id: UUID = UUID()
    var code: String
    var createdAt: Date
    var expiresAt: Date
    var isActive: Bool = true

    var daysLeft: Int {
        max(0, Calendar.current.dateComponents([.day], from: Date(), to: expiresAt).day ?? 0)
    }

    var isExpired: Bool { expiresAt <= Date() }
}

@MainActor
final class CodeStore: ObservableObject {
    @Published var codes: [LicenseCode] = [] { didSet { save() } }
    @Published var duration = 30
    @Published var latestCode = ""

    private let key = "tshiki.licenses"

    init() { load() }

    func generate() {
        let alphabet = Array("ABCDEFGHJKLMNPQRSTUVWXYZ23456789")
        let token = String((0..<12).compactMap { _ in alphabet.randomElement() })
        let code = "Tshiki-" + token
        let expiry = Calendar.current.date(byAdding: .day, value: duration, to: Date()) ?? Date()
        let item = LicenseCode(code: code, createdAt: Date(), expiresAt: expiry)
        codes.insert(item, at: 0)
        latestCode = code
    }

    func toggle(_ item: LicenseCode) {
        guard let index = codes.firstIndex(where: { $0.id == item.id }) else { return }
        codes[index].isActive.toggle()
    }

    func reset(_ item: LicenseCode) {
        guard let index = codes.firstIndex(where: { $0.id == item.id }) else { return }
        codes[index].createdAt = Date()
        codes[index].expiresAt = Calendar.current.date(byAdding: .day, value: duration, to: Date()) ?? Date()
        codes[index].isActive = true
    }

    func delete(_ item: LicenseCode) { codes.removeAll { $0.id == item.id } }

    private func save() {
        if let data = try? JSONEncoder().encode(codes) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }

    private func load() {
        guard let data = UserDefaults.standard.data(forKey: key),
              let saved = try? JSONDecoder().decode([LicenseCode].self, from: data) else { return }
        codes = saved
    }
}

@main
struct TshikiCodeManagerApp: App {
    var body: some Scene {
        WindowGroup { ContentView().preferredColorScheme(.dark) }
    }
}

struct ContentView: View {
    @StateObject private var store = CodeStore()
    @State private var copied = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("TSHIKI").font(.system(size: 30, weight: .black, design: .rounded)).foregroundStyle(.mint)
                        Text("CODE MANAGER").font(.caption.weight(.bold)).tracking(3).foregroundStyle(.secondary)
                    }
                    .padding(.top, 8)

                    VStack(alignment: .leading, spacing: 14) {
                        Text("إنشاء كود جديد").font(.headline)
                        HStack {
                            Text("مدة الصلاحية")
                            Spacer()
                            Picker("مدة الصلاحية", selection: $store.duration) {
                                Text("يوم واحد").tag(1)
                                Text("7 أيام").tag(7)
                                Text("30 يوم").tag(30)
                                Text("90 يوم").tag(90)
                                Text("365 يوم").tag(365)
                            }.pickerStyle(.menu).tint(.mint)
                        }
                        Button(action: store.generate) {
                            Label("إنشاء كود عشوائي", systemImage: "plus.circle.fill")
                                .font(.headline).frame(maxWidth: .infinity).padding(.vertical, 13)
                        }
                        .buttonStyle(.borderedProminent).tint(.mint)
                        if !store.latestCode.isEmpty {
                            HStack {
                                Text(store.latestCode).font(.system(.subheadline, design: .monospaced)).textSelection(.enabled)
                                Spacer()
                                Button {
                                    UIPasteboard.general.string = store.latestCode
                                    copied = true
                                } label: { Image(systemName: copied ? "checkmark" : "doc.on.doc") }
                                .tint(.mint)
                            }
                            .padding(12).background(.black.opacity(0.25), in: RoundedRectangle(cornerRadius: 12))
                        }
                    }
                    .padding(16).background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 18))

                    HStack {
                        Text("الأكواد").font(.title2.bold())
                        Spacer()
                        Text("\(store.codes.count) كود").font(.caption).foregroundStyle(.secondary)
                    }

                    if store.codes.isEmpty {
                        ContentUnavailableView("لا توجد أكواد", systemImage: "key.horizontal", description: Text("أنشئ أول كود من الأعلى."))
                    } else {
                        ForEach(store.codes) { item in
                            CodeCard(item: item,
                                     onToggle: { store.toggle(item) },
                                     onReset: { store.reset(item) },
                                     onDelete: { store.delete(item) })
                        }
                    }
                    Text("ملاحظة: هذه نسخة محلية تجريبية؛ الأكواد محفوظة على هذا الجهاز فقط ولا تُزامَن مع خادم.")
                        .font(.footnote).foregroundStyle(.secondary).padding(.top, 4)
                }
                .padding(18)
            }
            .background(Color(red: 0.035, green: 0.065, blue: 0.09))
            .toolbar(.hidden, for: .navigationBar)
        }
    }
}

struct CodeCard: View {
    let item: LicenseCode
    let onToggle: () -> Void
    let onReset: () -> Void
    let onDelete: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(item.code).font(.system(.headline, design: .monospaced)).textSelection(.enabled)
                Spacer()
                Text(item.isActive ? (item.isExpired ? "منتهي" : "نشط") : "موقوف")
                    .font(.caption.bold()).padding(.horizontal, 10).padding(.vertical, 6)
                    .background((item.isActive && !item.isExpired ? Color.mint : Color.red).opacity(0.16), in: Capsule())
            }
            HStack(spacing: 16) {
                Label(item.isExpired ? "0 يوم متبقي" : "\(item.daysLeft) يوم متبقي", systemImage: "calendar")
                Spacer()
                Text("ينتهي: \(item.expiresAt.formatted(date: .numeric, time: .omitted))")
            }
            .font(.caption).foregroundStyle(.secondary)
            HStack {
                Button(item.isActive ? "إيقاف الكود" : "تفعيل الكود", action: onToggle)
                    .buttonStyle(.bordered).tint(item.isActive ? .orange : .mint)
                Button("Reset", action: onReset).buttonStyle(.bordered).tint(.blue)
                Spacer()
                Button(role: .destructive, action: onDelete) { Image(systemName: "trash") }.buttonStyle(.bordered)
            }
        }
        .padding(15).background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 16))
    }
}
